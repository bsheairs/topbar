//
//  DKTestConstants.h
//  DataKit
//
//  Created by Erik Aigner on 21.03.12.
//  Copyright (c) 2012 chocomoko.com. All rights reserved.
//

#define kDKEndpoint @"http://localhost:3000"
#define kDKSecret @"c821a09ebf01e090a46b6bbe8b21bcb36eb5b432265a51a76739c20472908989"
#define kDKDB @"datakit"