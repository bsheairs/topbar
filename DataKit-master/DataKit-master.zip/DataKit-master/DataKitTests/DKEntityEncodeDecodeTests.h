//
//  DKEntityEncodeDecodeTests.h
//  DataKit
//
//  Created by Erik Aigner on 04.03.12.
//  Copyright (c) 2012 chocomoko.com. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface DKEntityEncodeDecodeTests : SenTestCase

@end
