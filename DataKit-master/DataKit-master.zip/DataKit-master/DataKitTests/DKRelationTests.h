//
//  DKRelationTests.h
//  DataKit
//
//  Created by Erik Aigner on 05.03.12.
//  Copyright (c) 2012 chocomoko.com. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface DKRelationTests : SenTestCase

@end
