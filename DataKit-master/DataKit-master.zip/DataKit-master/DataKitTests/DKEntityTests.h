//
//  DKEntityTests.h
//  DataKit
//
//  Created by Erik Aigner on 24.02.12.
//  Copyright (c) 2012 chocomoko.com. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface DKEntityTests : SenTestCase

@end
