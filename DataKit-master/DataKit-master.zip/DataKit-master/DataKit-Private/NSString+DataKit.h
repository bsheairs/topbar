//
//  NSString+DataKit.h
//  DataKit
//
//  Created by Erik Aigner on 28.02.12.
//  Copyright (c) 2012 chocomoko.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (DataKit)

- (NSString *)URLEncoded UNAVAILABLE_ATTRIBUTE;

@end
